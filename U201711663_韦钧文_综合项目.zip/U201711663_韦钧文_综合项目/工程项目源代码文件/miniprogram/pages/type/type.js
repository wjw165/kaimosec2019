var wxCharts = require('../../wxcharts.js');
var app = getApp();
var pieChart1 = null;
var pieChart2 = null;
Page({
  data: {
    total_number: 0,
     area: ['软件', '硬件', '嵌入式开发', '人工智能', '机器学习', '大数据', '管理学', '心理学', '化学', '人文科学', '机器人'],
    areaIndex: 0
  },


  bindMultiPickerChange: function (e) {
    console.log(e.detail.value);
    this.setData({
      areaIndex: e.detail.value
    })

    var that = this;
    var item = new Array;

    wx.request({
      url: 'http://106.53.92.89:4000/api/chart/type?type=' + that.data.area[that.data.areaIndex],
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(that.data.area[that.data.areaIndex])
          item  =  res.data
      
        
        var windowWidth = 320;
        try {
          var re = wx.getSystemInfoSync();
          windowWidth = re.windowWidth;
        } catch (e) {
          console.error('getSystemInfoSync failed!');
        }
         
        var i1 = parseInt(item.country)
        var i2 = parseInt(item.college)
        var i3 = parseInt(item.university)
        that.setData({
          total_number:i1+i2+i3
        })
        pieChart1 = new wxCharts({
          animation: true,
          canvasId: 'pieCanvas1',
          type: 'pie',
          series: [{
            name: '国家级',
            data: i1
          }, {
            name: '校级',
            data: i2
          }, {
            name: '院级',
            data: i3
          }],
          width: windowWidth,
          height: 300,
          dataLabel: true,
        })
        pieChart2 = new wxCharts({
          animation: true,
          canvasId: 'pieCanvas2',
          type: 'pie',
          series: [{
            name: '优秀',
            data: parseInt(res.data.perfect)
          }, {
            name: '良好',
              data: parseInt(res.data.great)
          }, {
            name: '合格',
              data: parseInt(res.data.normall)
          }],
          width: windowWidth,
          height: 300,
          dataLabel: true,
        });
      }
    })
  
    },
  onLoad: function () {
  }
});