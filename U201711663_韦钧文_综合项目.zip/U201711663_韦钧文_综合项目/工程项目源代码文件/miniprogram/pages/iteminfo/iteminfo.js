// miniprogram/pages/xiangmu/xiangmu.js
var imformation_key;
const app = getApp()

var show=0;
var item = new Array;

Page({
  
  /**
   * 页面的初始数据
   */
  data: {
  
    focus:1
  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    var that = this
    var itemid = options.itemid;
    that.setData({
      itemid: options.itemid
    });
    wx.request({
      url: 'http://106.53.92.89:4000/api/information/' + itemid, //仅为示例，并非真实的接口地址
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        that.setData({
          item :res.data});
    
      }
    })
    var info = new Array;
    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/userinfor?openid=' + app.globalData.openid,
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        that.setData({
          info: res.data
        });

      }
    })
   

    
     
    
  },

  showdetail:function(event){
    show=!show;
    this.setData({show})
    var that = this;
    var list = new Array;

    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/userinfor?openid=' + this.data.item._openid,
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
      
        that.setData({
          list: res.data
        });
      }
    })


    if (this.data.info.focusFifth == this.data.item._openid || this.data.info.focusFourth == this.data.item._openid || this.data.info.focusThird == this.data.item._openid || this.data.info.focusSecond == this.data.item._openid || this.data.info.focusFirst == this.data.item._openid || app.globalData.openid == this.data.item._openid) {
   
      this.setData({
        focus:0
      })
    }
  },
  



  
  focusteacher:function(){
var that = this
    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/userfocus?',
      data: {

        openid: app.globalData.openid,
        number:this.data.itemid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data) {
          wx.showToast({
            title: '成功关注',
            icon: 'success',
            duration: 2000
          })
          that.setData({
            focus: 0
          })

          }
        else {
          wx.showToast({
            title: '关注失败',
            icon: 'cancel',
            duration: 2000
          })

          }

      }
    })
   
  },
  unfocus:function(){
    var that = this
    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/usercancelfocus?',
      data: {

        openid: app.globalData.openid,
        openidde: this.data.item._openid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data) {
          wx.showToast({
            title: '取消关注',
            icon: 'success',
            duration: 2000
          })

          that.setData({
            focus: 1
          })
          }
        
         }

    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },




})