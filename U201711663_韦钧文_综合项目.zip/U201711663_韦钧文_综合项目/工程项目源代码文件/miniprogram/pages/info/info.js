// miniprogram/pages/stuinfo/stuinfo.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    disabled: false,
    logged: false,
    openid:''

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取用户信息
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid

        var user = new Array;
        db.collection('Teacher').where({
          _openid: app.globalData.openid
        })
          .get({
            success: res => {
              user = res.data;
              console.log(res.data)
              this.setData(
                user[0]
              );

            }
          })
          
        var person = new Array;
        db.collection('Information').where({
          _openid: app.globalData.openid
        })
          .get({
            success: res => {
              person = res.data;
              console.log(res.data)
              this.setData(
                person[0]
              );

            }
          })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
       
      }
    })
    
    
  },
  wxchange: function (event) {
   
    wx.redirectTo({
      url: "../change/change"
    })
  },
  wxadd: function (event) {

    wx.redirectTo({
      url: "../itemadd/itemadd"
    })
  },
  input: function (event) {

    wx.redirectTo({
      url: "../input/input",
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})