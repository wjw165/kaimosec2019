// miniprogram/pages/input/input.js

const app = getApp()

Page({

      /**
       * 页面的初始数据
       */
      data: {

      },

      /**
       * 生命周期函数--监听页面加载
       */
      onLoad: function(options) {

      },

      /**
       * 生命周期函数--监听页面初次渲染完成
       */
      onReady: function() {

      },

      /**
       * 生命周期函数--监听页面显示
       */
      onShow: function() {

      },

      /**
       * 生命周期函数--监听页面隐藏
       */
      onHide: function() {

      },

      /**
       * 生命周期函数--监听页面卸载
       */
      onUnload: function() {

      },

      /**
       * 页面相关事件处理函数--监听用户下拉动作
       */
      onPullDownRefresh: function() {

      },

      /**
       * 页面上拉触底事件的处理函数
       */
      onReachBottom: function() {

      },

      /**
       * 用户点击右上角分享
       */
      onShareAppMessage: function() {

      },


      bindKeyInput: function(e) {
        this.setData({
          inputValue: e.detail.value
        })

      },

      userNameInput: function(e) {

        this.setData({
          userN: e.detail.value
        })
      },

      passWordInput: function(e) {
        this.setData({
          passW: e.detail.value
        })
      },

      loginBtnClick: function(a) {
          var that = this
          if (this.data.userN.length == 0 || this.data.passW.length == 0) {
            wx.showModal({
              title: '温馨提示：',
              content: '用户名或密码不能为空！',
              showCancel: false
            })
           } else {
            wx.request({
                url: 'http://106.53.92.89:4000/api/values?',
                data: {

                  Account: this.data.userN ,
                  Password:this.data.passW ,
                  openid:app.globalData.openid,
                },
                header: {
                  'content-type': 'application/json' // 默认值
                },
                success(res) {
                  if (res.data) {
                    wx.showToast({
                      title: '成功认证',
                      icon: 'success',
                      duration: 2000
                    })

                    wx.switchTab({
                      url: "../person/person"
                    })
                  } else {
                    wx.showToast({
                      title: '认证失败',
                      icon: 'cancel',
                      duration: 2000
                    })
                  }
                }
            })
           }
      }
            })