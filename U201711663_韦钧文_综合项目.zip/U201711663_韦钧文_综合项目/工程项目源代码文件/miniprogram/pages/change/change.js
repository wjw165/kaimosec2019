// pages/change/change.js
const app = getApp()
var list = new Array;
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  formSubmit: function(e) {
    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/userpost?',
      data: {
        openid:app.globalData.openid,
        name: e.detail.value.name,
        major: e.detail.value.major,
        email: e.detail.value.email,
        wxid: e.detail.value.wx_Id,
        phone: e.detail.value.phone,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data) {
          wx.showToast({
            title: '成功修改',
            icon: 'success',
            duration: 2000
          })

          wx.switchTab({
            url: "../person/person"
          })
        } 
        else {
  
            wx.showToast({
            title: '修改失败',
            icon: 'cancel',
            duration: 2000
          })
        }
      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    var that = this
    wx.request({
      url: 'http://106.53.92.89:4000/api/personinfor/userinfor?openid=' +app.globalData.openid,
       data: {
     
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
          that.setData({
            list: res.data,
          })
          console.log(res.data)
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },



  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})