var wxCharts = require('../../wxcharts.js');
var app = getApp();
var lineChart = null;
Page({
  data: {
    area: ['软件', '硬件', '嵌入式开发', '人工智能', '机器学习', '大数据', '管理学', '心理学', '化学', '人文科学', '机器人'],
    areaIndex: 0
  },


  bindMultiPickerChange: function (e) {
    console.log(e.detail.value);
    this.setData({
      areaIndex: e.detail.value
    })

    var that = this;
    var item = new Array;

    wx.request({
      url: 'http://106.53.92.89:4000/api/chart/year?type=' + that.data.area[that.data.areaIndex],
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(that.data.area[that.data.areaIndex])
        item = res.data


        var windowWidth = 320;
        try {
          var re = wx.getSystemInfoSync();
          windowWidth = re.windowWidth;
        } catch (e) {
          console.error('getSystemInfoSync failed!');
        }

        var i1 = parseInt(item.eleven)
        var i2 = parseInt(item.twelve)
        var i3 = parseInt(item.thirteen)
        var i4 = parseInt(item.fourteen)
        var i5 = parseInt(item.fifteen)
        var i6 = parseInt(item.sixteen)
        var i7 = parseInt(item.seventeen)
        var i8 = parseInt(item.eighteen)
        var i9 = parseInt(item.nineteen)
        var i10 = parseInt(item.twenty)
        var simulationData = that.createSimulationData();
        lineChart = new wxCharts({
          canvasId: 'lineCanvas',
          type: 'line',


          categories: simulationData.categories,
          animation: true,
      
          series: [{

            name: that.data.area[that.data.areaIndex],
            data: [i1, i2, i3, i4, i5, i6, i7, i8, i9],
            format: function (val, name) {
              return val.toFixed(0) + '个';
            }
          }],
          xAxis: {
            disableGrid: true
          },
          yAxis: {
            title: '数量 (个)',
            format: function (val) {
              return val.toFixed(0);
            },
            min: 0
          },
          width: windowWidth,
          height: 200,
          dataLabel: false,
          dataPointShape: true,
          extra: {
            lineStyle: 'curve'
          }
        });
      }
    })

  },
  touchHandler: function (e) {
    console.log(lineChart.getCurrentDataIndex(e));
    lineChart.showToolTip(e, {
      // background: '#7cb5ec',
      format: function (item, category) {
        return category + ' ' + item.name + ':' + item.data
      }
    });
  },
  createSimulationData: function () {
    var categories = [];
    var data = [];
    for (var i = 0; i < 9; i++) {
      categories.push((2011 + i ) + '年');

    }

    return {
      categories: categories,
      data: data
    }
  },
  onLoad: function () {
  }
});