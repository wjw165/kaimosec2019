var item_key = new Array;
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
    cardCur: 0,
    swiperList: [{
      id: 0,
      type: 'image',
      url: '/images/chuang.jpg'
    }, {
      id: 1,
      type: 'image',
      url: '/images/chuang1.jpg',
    }, {
      id: 2,
      type: 'image',
      url: '/images/chuang3.jpg'
    } ],
    
  },


  /**
   * 生命周期函数--监听页面加载
   */
 

  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
    var list = new Array;
    var that = this
    wx.request({
      url: 'http://106.53.92.89:4000/api/information/itemselect' ,
      data: {
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          list: res.data
        });
        console.log(res.data)

      }
    })
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
      }
    })
  },

  cardSwiper(e){

    this.setData({
      cardCur: e.detail.current
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

