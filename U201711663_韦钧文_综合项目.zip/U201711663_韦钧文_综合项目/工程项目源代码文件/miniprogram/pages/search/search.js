var item_key = new Array;
var t = 0; //种类
var n = 0; //下一页
var list = new Array;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    var that = this
    wx.request({
      url: 'http://106.53.92.89:4000/api/values/itemsearchproto',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) { //将获取到的json数据，存在名字叫list的这个数组中       
        that.setData({
          list:res.data,
        })
        console.log(res.data)
      }
    })


  },

  inputBind: function(event) {

    this.setData({
      inputValue: event.detail.value
    })
    console.log('bindblur' + this.data.inputValue)
  },

  input: function(event) {

    this.setData({
      inputValue: event.detail.value
    })
    console.log('bindInput' + this.data.inputValue)
  },


  search: function(e) {
    console.log('bindInput' + this.data.inputValue)
    var that = this
    this.setData({
      texta: that.data.inputValue
    })
    wx.navigateTo({
      url: '../result/result?texta=' + this.data.texta,
    })
  },



  detail: function(event) {
    var itemid = event.currentTarget.dataset.number;
    console.log(itemid)
    console.log(event.currentTarget.dataset.number)

    wx.navigateTo({
      url: '../iteminfo/iteminfo?itemid=' + itemid,
    })

  },




  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})