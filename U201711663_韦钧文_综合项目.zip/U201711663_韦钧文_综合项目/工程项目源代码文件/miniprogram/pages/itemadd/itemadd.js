var Zan = require('../../dist/index');
const app = getApp()
const db = wx.cloud.database()
areaIndex: 0
Page(Object.assign({}, Zan.Field, {
  data: {
    area: ['软件', '硬件', '嵌入式开发', '人工智能', '机器学习', '大数据', '管理学', '心理学', '化学', '人文科学', '机器人'],
    areaIndex: 0
  },

  onAreaChange(e) {
    this.setData({
      areaIndex: e.detail.value
    });
  },

  handleZanFieldChange(e) {
    const { componentId, detail } = e;
    console.log('[zan:field:change]', componentId, detail);
  },


  formSubmit: function (e) {
    console.log(app.globalData.openid),
      console.log(e.detail.value.item_name),
      console.log(this.data.area[e.detail.value.customer_date]),
      console.log(e.detail.value.introduction)
    wx.request({
      url: 'http://106.53.92.89:4000/api/information/itempost?',
      data: {
        openid: app.globalData.openid,
        name: e.detail.value.item_name,
        type: this.data.area[e.detail.value.customer_date],
        introduction: e.detail.value.introduction
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data) {
          wx.showToast({
            title: '成功发布',
            icon: 'success',
            duration: 2000
          })

          wx.switchTab({
            url: "../person/person"
          })
        }
        else {
          
          wx.showToast({
            title: '发布失败',
            icon: 'cancel',
            duration: 2000
          })
        }
      }
    })

  }
  
}));
