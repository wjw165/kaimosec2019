
const cloud = require('wx-server-sdk')
cloud.init()

exports.main = async (event, context) => {
  console.log(event)
  return sendTemplateMessage(event)
}


async function sendTemplateMessage(event) {
  const {
    OPENID
  } = cloud.getWXContext()


  const addResult = await cloud.openapi.templateMessage.addTemplate({
    id: 'AT0286',
    keywordIdList: [3,7]
  })

  const templateId = addResult.templateId 

  const sendResult = await cloud.openapi.templateMessage.send({
    touser: OPENID,
    templateId,
    formId: event.formId,
    page: 'pages/index/index',
    data: {
      keyword1: {
        value: '有新项目信息',
      },
      keyword2: {
        value: '您关注的老师',
      },
      
      
    }
  })

 
  await cloud.openapi.templateMessage.deleteTemplate({
    templateId,
  })

  return sendResult
}
