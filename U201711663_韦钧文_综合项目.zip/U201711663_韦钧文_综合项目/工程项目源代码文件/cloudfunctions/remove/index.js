// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {

  try {
    console.log("event")
    console.log(event)
    return await db.collection('items').where({
      _id: event._id
    })
      .remove()
  } catch (e) {
    console.error(e)
  }
}